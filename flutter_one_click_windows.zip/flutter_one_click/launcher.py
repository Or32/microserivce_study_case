import functools
import http.server
import mimetypes
import os
from pathlib import Path
import socketserver
import sys
import threading
import tkinter as tk
import webbrowser
from tkinter import ttk, messagebox


mimetypes.add_type("application/wasm", ".wasm")
mimetypes.add_type("text/javascript", ".mjs")
mimetypes.add_type("application/manifest+json", ".webmanifest")


class FlutterHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, web_root: Path, **kwargs):
        super().__init__(*args, directory=str(web_root), **kwargs)

    def do_GET(self):
        request_path = self.path.split("?", 1)[0].split("#", 1)[0]
        resource = Path(self.translate_path(request_path))
        if not resource.is_file() and not resource.is_dir():
            accepts_html = "text/html" in self.headers.get("Accept", "")
            has_file_extension = bool(Path(request_path).suffix)
            if accepts_html and not has_file_extension:
                self.path = "/index.html"
        super().do_GET()

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()


class LocalServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def locate_web_root():
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
    return base / "web"


def main():
    web_root = locate_web_root()
    if not (web_root / "index.html").is_file():
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Flutter launcher", "Missing web/index.html in the packaged application.")
        root.destroy()
        return

    handler = functools.partial(FlutterHandler, web_root=web_root)
    try:
        server = LocalServer(("127.0.0.1", 0), handler)
    except OSError as error:
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Flutter launcher", f"Could not start local server: {error}")
        root.destroy()
        return

    url = f"http://127.0.0.1:{server.server_port}/"
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    window = tk.Tk()
    window.title("Flutter Web")
    window.geometry("390x160")
    window.resizable(False, False)

    frame = ttk.Frame(window, padding=18)
    frame.pack(fill="both", expand=True)
    ttk.Label(frame, text="Your Flutter application is running", font=("Segoe UI", 11, "bold")).pack(pady=(0, 8))
    ttk.Label(frame, text=url).pack()
    button_row = ttk.Frame(frame)
    button_row.pack(pady=(18, 0))

    def close_app():
        window.destroy()
        server.shutdown()
        server.server_close()

    ttk.Button(button_row, text="Open website", command=lambda: webbrowser.open(url)).pack(side="left", padx=6)
    ttk.Button(button_row, text="Stop server", command=close_app).pack(side="left", padx=6)
    window.protocol("WM_DELETE_WINDOW", close_app)
    window.after(300, lambda: webbrowser.open(url))
    window.mainloop()


if __name__ == "__main__":
    main()
