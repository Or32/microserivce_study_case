@echo off
setlocal
cd /d "%~dp0"

if not exist "web\index.html" (
  echo ERROR: Missing web\index.html
  echo Copy ALL files from your Flutter project's build\web folder into the web folder here.
  pause
  exit /b 1
)

py -3 -m pip --version >nul 2>&1
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  python -m pip --version >nul 2>&1
  if errorlevel 1 (
    echo ERROR: Install Python from https://www.python.org/downloads/windows/
    echo Then run this script again.
    pause
    exit /b 1
  )
  set "PY=python"
)

%PY% -m pip install --upgrade pyinstaller
if errorlevel 1 goto :failed

%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name FlutterWeb --add-data "web;web" launcher.py
if errorlevel 1 goto :failed

echo.
echo SUCCESS: dist\FlutterWeb.exe
pause
exit /b 0

:failed
echo.
echo Build failed. Review the errors above.
pause
exit /b 1
