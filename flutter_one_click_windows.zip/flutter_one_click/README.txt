FLUTTER WEB ONE-CLICK WINDOWS EXE
================================

1. Build Flutter web on your developer machine:
   flutter build web --release

2. Copy EVERYTHING INSIDE build/web into the 'web' folder in this package.
   Keep the full Flutter build tree (assets, canvaskit, JS, etc.).

3. On a Windows PC with Python 3 installed, double-click build-exe.bat.
   Internet access is needed for the initial PyInstaller install.

4. Your self-contained app will be at: dist/FlutterWeb.exe
   Copy this file alone to any compatible Windows PC and double-click it.
   The browser opens automatically. Use the small control window to stop the server.

Notes:
- No Flutter, Python or Node.js is required on target PCs.
- The server binds to 127.0.0.1 on an available random port; remote devices cannot connect.
- Flutter web must work as static files. Backend API calls still require their own backend.
- The EXE runs entirely locally, but Flutter apps requiring external CDNs, APIs or fonts
  will still need network unless those resources are bundled separately.
- Some antivirus systems may scan or warn about unsigned one-file executables.
- Build the executable on Windows, ideally on the same architecture as target PCs.
